# IAS Spring 2021-Group 6
## Distributed platform for IoT Applications
