import time
for i in range(200):
    print(i)
    