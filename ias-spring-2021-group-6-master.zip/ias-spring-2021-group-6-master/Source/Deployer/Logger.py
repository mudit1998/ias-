def Log(toLog):
    print(toLog)