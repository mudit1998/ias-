from random import randint
x, y = randint(0, 7), randint(0, 7)
data=str(x)+":"+str(y)
print(data)