python3 -u buzzer_bus1.py > bus1out.txt &
python3 -u buzzer_bus2.py > bus2out.txt &
python3 -u buzzer_bus3.py > bus3out.txt &
python3 -u buzzer_bus4.py > bus4out.txt &
python3 -u ac_bus1.py > ac1out.txt &
python3 -u ac_bus2.py > ac2out.txt &
python3 -u light_cont_bus1.py > light1out.txt &
python3 -u light_cont_bus2.py > light2out.txt &
python3 -u ac_bus3.py > ac3out.txt &
python3 -u ac_bus4.py > ac4out.txt &
python3 -u light_cont_bus3.py > light3out.txt &
python3 -u light_cont_bus4.py > light4out.txt &

