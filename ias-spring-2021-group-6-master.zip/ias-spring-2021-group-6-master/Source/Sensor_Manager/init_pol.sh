python3 -u air1.py > air1.txt &
python3 -u audio1.py > audio1.txt &
python3 -u camera1.py > camera1.txt &
python3 -u signal_traff_2.py > signal_traff2.txt &
python3 -u air2.py > air2.txt &
python3 -u audio2.py > audio2.txt &
python3 -u camera2.py > camera2.txt &
python3 -u signal_traff_1.py > signal_traff_1.txt &
